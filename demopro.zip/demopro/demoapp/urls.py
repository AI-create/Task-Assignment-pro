from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'users', views.UserViewSet)
router.register(r'tasks', views.TaskViewSet, basename='task')

urlpatterns = [
    path('api/', include(router.urls)),
]



'''
# URL Dcoumentation

 # User-related URLs
    path('api/users/', views.UserListView.as_view(), name='user-list'),
    path('api/users/<int:pk>/', views.UserDetailView.as_view(), name='user-detail'),
    path('api/users/login/', views.LoginView.as_view(), name='user-login'),
    path('api/users/logout/', views.LogoutView.as_view(), name='user-logout'),
    path('api/users/register/', views.UserViewSet.as_view({'post': 'register'}), name='user-register'),


    # Task-related URLs

    Create task: http://localhost:8000/api/tasks/create_task/
    Update task: http://localhost:8000/api/tasks/<task_id>/update_task/
    Delete task: http://localhost:8000/api/tasks/<task_id>/delete_task/
    Mark as completed: http://localhost:8000/api/tasks/<task_id>/complete_task/
    List all completed tasks: http://localhost:8000/api/tasks/list_all_completed/



    # Assuming you have a view that filters tasks by assigned user
    path('api/tasks/assigned/<int:user_id>/', views.TasksAssigned'''