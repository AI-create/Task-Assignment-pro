from django.contrib.auth import get_user_model, authenticate
from rest_framework.authtoken.models import Token
from .models import Task
from .serializers import UserSerializer, TaskSerializer
from .permissions import CustomPermission
from rest_framework.permissions import IsAuthenticated
from rest_framework.authentication import TokenAuthentication
from django.contrib.auth import authenticate
from rest_framework.decorators import action
from rest_framework import status
from rest_framework.authtoken.models import Token
from rest_framework.permissions import AllowAny
from django.views.decorators.csrf import csrf_exempt
from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.decorators import authentication_classes



class UserViewSet(viewsets.ModelViewSet):
    queryset = get_user_model().objects.all()
    serializer_class = UserSerializer
    permission_classes = [CustomPermission]

    @csrf_exempt
    @action(detail=False, methods=['POST'], permission_classes=[])
    @authentication_classes([])
    def register(self, request):
        serializer = UserSerializer(data=request.data)
        if serializer.is_valid():
            user = get_user_model().objects.create_user(
                username=serializer.validated_data['username'],
                email=serializer.validated_data['email'],
                password=serializer.validated_data['password'],
                role=serializer.validated_data['role']
            )
            return Response({
                'token': Token.objects.create(user=user).key,
                'role': user.role
            }, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    @csrf_exempt
    @action(detail=False, methods=['POST'], permission_classes=[AllowAny])
    @authentication_classes([TokenAuthentication])
    def login(self, request):
        username = request.data.get("username")
        password = request.data.get("password")
        user = authenticate(request, username=username, password=password)
        if user:
            # User authenticated
            token, _ = Token.objects.get_or_create(user=user)
            return Response({"token": token.key}, status=status.HTTP_200_OK)
        else:
            # Authentication failed
            return Response({"error": "Invalid Credentials"}, status=status.HTTP_401_UNAUTHORIZED)

    @csrf_exempt
    @action(detail=False, methods=['POST'], permission_classes=[IsAuthenticated])
    @authentication_classes([TokenAuthentication])
    def logout(self, request):
        request.auth.delete()
        return Response(status=status.HTTP_200_OK)


class TaskViewSet(viewsets.ModelViewSet):
    queryset = Task.objects.all()  
    serializer_class = TaskSerializer
    permission_classes = [CustomPermission]


    def get_queryset(self):
        user = self.request.user
        if user.is_authenticated:  
            if user.role == 'ADMIN':
                return Task.objects.all()
            elif user.role == 'MANAGER':
                return Task.objects.filter(assigned_to=user)
            elif user.role == 'EMPLOYEE':
                return Task.objects.filter(assigned_to=user)
        return Task.objects.none()  

    @action(detail=False, methods=['POST'])
    def create_task(self, request, *args, **kwargs):
        print("Inside create_task method")
        print(f"Request data: {request.data}")
        print(f"User role: {request.user.role}")
        if request.user.role not in ['ADMIN', 'MANAGER']:
            return Response({"detail": "You do not have permission to create tasks."}, status=status.HTTP_403_FORBIDDEN)
        
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



    @action(detail=True, methods=['PUT'])
    def update_task(self, request, *args, **kwargs):
        user = self.request.user
        instance = self.get_object()

        # If Employee, allow them to only mark tasks as completed
        if user.role == 'EMPLOYEE':
            if instance.assigned_to != user:
                return Response({"detail": "You do not have permission to update this task."}, status=status.HTTP_403_FORBIDDEN)
            
            # Only allow status changes here
            data = request.data
            if 'status' in data and data['status'] == 'COMPLETED':
                instance.status = 'COMPLETED'
                instance.save()
                return Response({"detail": "Task marked as completed."}, status=status.HTTP_200_OK)

            return Response({"detail": "Invalid operation."}, status=status.HTTP_400_BAD_REQUEST)

        # For ADMIN and MANAGER
        elif user.role in ['ADMIN', 'MANAGER']:
            
            # Logic to allow re-assigning tasks (for Admin)
            if user.role == 'ADMIN':
                assigned_to_username = request.data.get('assigned_to')
                if assigned_to_username:
                    try:
                        assigned_user = get_user_model().objects.get(username=assigned_to_username)
                        instance.assigned_to = assigned_user
                    except get_user_model().DoesNotExist:
                        return Response({"detail": "Assigned user does not exist."}, status=status.HTTP_400_BAD_REQUEST)
            
            instance.save()
            
        else:
            return Response({"detail": "You do not have permission to update tasks."}, status=status.HTTP_403_FORBIDDEN)
        
        return super().update(request, *args, **kwargs)


    @action(detail=True, methods=['DELETE'])
    def delete_task(self, request, *args, **kwargs):
        if request.user.role not in ['ADMIN', 'MANAGER']:
            return Response({"detail": "You do not have permission to delete tasks."}, status=status.HTTP_403_FORBIDDEN)
        return super().destroy(request, *args, **kwargs)


    @action(detail=True, methods=['POST'], permission_classes=[CustomPermission])
    def complete_task(self, request, pk=None):
        task = self.get_object()
        
        # Your logic to mark the task as completed
        task.status = 'COMPLETED'
        task.save()
        
        return Response({'status': 'Task marked as completed'}, status=status.HTTP_200_OK)

    @action(detail=False, methods=['GET'], permission_classes=[CustomPermission])
    def list_all_completed(self, request):
        completed_tasks = Task.objects.filter(status='COMPLETED')
        serializer = TaskSerializer(completed_tasks, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)