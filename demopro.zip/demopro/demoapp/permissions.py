from rest_framework import permissions
from demoapp.models import Task,User 
from rest_framework.exceptions import NotAuthenticated
# from .views import TaskViewSet, UserViewSet 
from rest_framework import permissions
from .models import Task, User  


class CustomPermission(permissions.BasePermission):

    def has_permission(self, request, view):
        if view.action in ['register', 'login', 'list', 'task', 'retrieve', 'create_task', 'update_task', 'delete_task', 'complete_task', 'list_all_completed']:
            if view.action in ['complete_task', 'list_all_completed']:
                return request.user.is_authenticated and request.user.role in ['ADMIN', 'MANAGER', 'EMPLOYEE']
            
            return True

        if not request.user or not request.user.is_authenticated:
            return False

        if view.basename == 'user':
            return True  

        elif view.basename == 'task':
            if view.action in ['list', 'retrieve']:
                return True  # Anyone authenticated can list or retrieve tasks

            if view.action in ['create_task', 'update_task', 'delete_task']:
                return request.user.role in ['ADMIN', 'MANAGER']

        return False

    def has_object_permission(self, request, view, obj):
        if view.basename == 'task':
            if request.user.role in ['ADMIN', 'MANAGER']:
                return True

            if request.user.role == 'EMPLOYEE':
                if view.action == 'complete_task':
                    return obj.assigned_to == request.user
                else:
                    return obj.assigned_to == request.user

        return False
